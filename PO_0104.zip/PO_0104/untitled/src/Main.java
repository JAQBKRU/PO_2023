public class Main {
    public static void main(String[] args) {
        /*Integer three = 3;
        Box box = new Box(three);
        System.out.println(box.value);*/

        Box<Integer, String> box = new Box<>(6, "Hej");
        Box<String, Integer> box2 = new Box<>("Hej", 6);
        Box<String, String> box3 = new Box<>("Hej", "Hej");

        wypisz(6);
        wypisz("Hej");
    }
    public static <T> void wypisz(T val){
        System.out.println(val);
    }
}