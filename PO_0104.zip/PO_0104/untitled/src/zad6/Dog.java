package zad6;

public class Dog extends Animal{
    private String name;

    public Dog(String name, int age) {
        super(age);
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
