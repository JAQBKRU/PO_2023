package zad2;
//Napisz generyczną metodę isEqual, która przyjmuje dwa dowolne obiekty tego samego typu i zwraca true, jeśli są one równe, w przeciwnym razie false.
public class Main {
    public static void main(String[] args) {
        Integer val1 = 5;
        Integer val2 = 3;
        System.out.println(isEqual(val1, val2));
    }

    public static <T, U> boolean isEqual(T val1, U val2){
        return val1.equals(val2);
    }
}
