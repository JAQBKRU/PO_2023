package zad1;

public class Triple <T, U, V>{
    T val1;
    U val2;
    V val3;

    public Triple(T val1, U val2, V val3) {
        this.val1 = val1;
        this.val2 = val2;
        this.val3 = val3;
    }

    public T getVal1() {
        return val1;
    }

    public U getVal2() {
        return val2;
    }

    public V getVal3() {
        return val3;
    }
}
