package zad3;

import java.util.ArrayList;

public class Counter <T>{
    private int licznik;
    T val;
    private ArrayList<T> elementy;

    public Counter() {
        this.elementy = new ArrayList<>();
    }

    public void add(T element) {
        elementy.add(element);
        licznik++;
    }

    public int getCount() {
        return licznik;
    }
}
