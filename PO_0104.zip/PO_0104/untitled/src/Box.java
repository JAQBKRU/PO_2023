public class Box <T, U>{
    T value;
    U value2;

    public Box(T value, U value2) {
        this.value = value;
        this.value2 = value2;
    }
}
