package zad3;
//Stwórz klasę generyczną Counter<T>, która będzie zliczać ilość dodanych elementów określonego typu. Klasa powinna mieć metodę add(T element), która dodaje element do wewnętrznej struktury, oraz metodę getCount(), która zwraca liczbę dodanych elementów.
public class Main {
    public static void main(String[] args) {
        Counter<Integer> intCounter = new Counter<>();
        intCounter.add(2);
        intCounter.add(1);
        System.out.println(intCounter.getCount());
    }
}
