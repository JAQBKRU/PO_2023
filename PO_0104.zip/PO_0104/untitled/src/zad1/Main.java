package zad1;
//Stwórz klasę generyczną Triple<T, U, V>, która może przechowywać trzy obiekty różnych typów. Zaimplementuj metody getFirst(), getSecond() i getThird() do pobierania odpowiednio pierwszego, drugiego i trzeciego elementu.
public class Main {
    public static void main(String[] args) {
        Triple<Integer, Integer, Integer> triple = new Triple<>(6, 3, 2);
        System.out.println(triple.getVal2());
    }
}
