package zad4;

import java.util.ArrayList;

//Napisz statyczną metodę generyczną swap, która przyjmuje tablicę dowolnego typu i dwa indeksy, a następnie zamienia miejscami elementy w tej tablicy pod wskazanymi indeksami. Metoda powinna działać dla tablicy każdego typu. Przykładowe wywołanie metody: swap(myArray, 0, 2);, gdzie myArray to tablica typu Integer[] lub dowolnego innego typu. Zabezpiecz metodę tak, aby nie można było wywołać błędu związanego z przekroczeniem zakresu tablicy.
public class Main {
    public static void main(String[] args) {
        /*ArrayList<Integer> lista = new ArrayList<Integer>() {{
            add(3);
            add(5);
            add(1);
        }};*/
        Integer[] lista = {3, 5, 1, 8, 6, 0};

        for(Integer n: lista){
            System.out.print(n + " ");
        }
        swap(lista, 1, 7);
        System.out.print("\n");
        for(Integer n: lista){
            System.out.print(n + " ");
        }
    }

    public static <T, U, K> void swap(T[] tab, int a, int b){
        if(a <= tab.length && b <= tab.length){
            T t = tab[a];
            tab[a] = tab[b];
            tab[b] = t;
        }
    }
}
