/*
public class Student2 implements Comparable<Student2>{
    String name;
    double averageGrade;
    int yearOfBirth;


    public Student2(String name, double averageGrade, int yearOfBirth) {
        this.name = name;
        this.averageGrade = averageGrade;
        this.yearOfBirth = yearOfBirth;
    }

    @Override
    public String toString() {
        return "" + averageGrade;
    }


}


*/
