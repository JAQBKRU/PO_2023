package zad7;

public class Pair<T> {
    private T first;
    private T second;

    public Pair() {
        first = null;
        second = null;
    }

    public Pair(T first, T second) {
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }

    public T getSecond() {
        return second;
    }

    public void setFirst(T newValue) {
        first = newValue;
    }

    public void setSecond(T newValue) {
        second = newValue;
    }
}

class Plant implements Comparable<Plant> {
    private String name;

    public Plant(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public int compareTo(Plant other) { return 0; }

}

class Tree extends Plant {
    private int height;

    public Tree(String name, int height) {
        super(name);
        this.height = height;
    }

    public int getHeight() {
        return height;
    }

    @Override
    public int compareTo(Plant other) {
        if (other instanceof Tree) {
            Tree otherTree = (Tree) other;
            return Integer.compare(this.height, otherTree.height);
        }
        return super.compareTo(other);
    }
}