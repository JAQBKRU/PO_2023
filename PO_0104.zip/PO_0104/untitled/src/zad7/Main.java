package zad7;
//Stwórz klasę generyczną Pair<T>, która przechowuje dwa obiekty tego samego typu. Następnie utwórz dwie klasy: Plant i Tree, gdzie Tree dziedziczy po Plant. Klasa Tree powinna posiadać prywatne pole height, którego nie posiada klasa Plant. Następnie napisz statyczną metodę generyczną findMinMaxHeight, która przyjmuje jako argument tablicę obiektów typu Tree oraz Pair<? super Tree> result. Metoda powinna zapisać (jako obiekty typu Tree) najniższe i najwyższe (pod kątem wysokości) drzewo z tablicy w drugim argumencie metody. Wykorzystaj też generyczny interfejs Comparable.
public class Main {
    public static void main(String[] args) {
        Tree[] trees = {
                new Tree("t1", 10),
                new Tree("t2", 8),
                new Tree("t3", 12)
        };

        Pair<Tree> result = new Pair<>(null, null);
        //findMinMaxHeight(trees, result);
    }

    public static <T extends Comparable<T>> void findMinMaxHeight(T[] array, Pair<? super T> result) {

    }
}
