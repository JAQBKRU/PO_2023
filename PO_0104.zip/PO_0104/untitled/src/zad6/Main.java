package zad6;
//Utwórz dwie klasy: Animal (Zwierzę) i Dog (Pies), gdzie Dog dziedziczy po Animal. Następnie napisz statyczną metodę generyczną findMax, która przyjmuje dwa argumenty: element1 i element2 typu extends Animal. Metoda powinna zwracać element większy według własnie zdefiniowanego kryterium porównania. W implementacji porównaj elementy bazując na wybranym przez siebie atrybucie, na przykład wieku.
public class Main {
    public static void main(String[] args) {
        Dog dog1 = new Dog("Budda", 9);
        Dog dog2 = new Dog("Box", 5);
        Dog maxDog = findMax(dog1, dog2);

        System.out.println(maxDog.getAge());
    }
    public static <T extends Animal> T findMax(T element1, T element2) {
        if (element1.getAge() > element2.getAge())
            return element1;
        return element2;
    }
}
