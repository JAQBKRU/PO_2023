package zad5;
//Napisz statyczną metodę generyczną minValue, która przyjmuje tablicę elementów typu generycznego T, gdzie T rozszerza Comparable<T>. Metoda powinna zwracać najmniejszy element z tablicy. Przetestuj tę metodę na tablicach zawierających różne typy porównywalnych obiektów, takie jak Integer, Double, czy String. Zabezpiecz metodę tak, aby nie można było jej wywołać z tablicą o zerowej liczbie elementów. Dodaj klasę ’Personz polaminameiagei przetestuj metodęminValuena tablicy obiektówPerson`.
public class Main {
    public static void main(String[] args) {
        Integer[] intArray = {5, 3, 8, 1, 7, 2};
        System.out.println(minValue(intArray));

        Person[] personList = {
                new Person("p1", 3),
                new Person("p2", 6),
                new Person("p3", 8),
                new Person("p4", 4),
                new Person("p5", 2)
        };

        Person minPerson = minValue(personList);
        System.out.println(minPerson.getAge());
    }

    public static <T extends Comparable<T>> T minValue(T[] tab){
        if (tab == null || tab.length == 0)
            return null;

        T min = tab[0];
        for (int i = 1; i < tab.length; i++) {
            if (min.compareTo(tab[i]) > 0)
                min = tab[i];
        }

        return min;
    }
}
class Person implements Comparable<Person>{
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }

    public int getAge() { return age; }

    @Override
    public int compareTo(Person other) {
        return Integer.compare(this.age, other.age);
    }
}
